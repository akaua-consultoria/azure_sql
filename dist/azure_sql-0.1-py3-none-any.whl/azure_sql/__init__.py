#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 30 19:05:33 2023

@author: nfamartins
"""


from .create_table import create_table
from .delete_table import delete_table
from .drop_table import drop_table
from .insert_table import insert_table